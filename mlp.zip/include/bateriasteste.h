#ifndef BATERIASTESTE_H
#define BATERIASTESTE_H

#include <stdlib.h>
#include <vector>

using namespace std;

class Baterias
{
    public:
        vector<vector<double> > testes;
        Baterias();
};

#endif // BATERIASTESTE_H
